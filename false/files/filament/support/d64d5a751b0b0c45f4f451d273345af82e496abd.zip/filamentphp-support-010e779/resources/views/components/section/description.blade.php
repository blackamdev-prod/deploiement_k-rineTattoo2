<p
    {{ $attributes->class(['fi-section-header-description']) }}
>
    {{ $slot }}
</p>
