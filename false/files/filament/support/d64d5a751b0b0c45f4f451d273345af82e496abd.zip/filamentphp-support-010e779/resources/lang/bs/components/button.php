<?php

return [

    'messages' => [
        'uploading_file' => 'Učitavanje fajlova...',
    ],

];
