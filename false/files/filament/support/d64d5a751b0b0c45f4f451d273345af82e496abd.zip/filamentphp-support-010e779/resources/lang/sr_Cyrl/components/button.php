<?php

return [

    'messages' => [
        'uploading_file' => 'Шаљем датотеку...',
    ],

];
