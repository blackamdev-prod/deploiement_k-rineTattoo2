<?php

return [

    'messages' => [
        'uploading_file' => 'Wysyłanie pliku...',
    ],

];
