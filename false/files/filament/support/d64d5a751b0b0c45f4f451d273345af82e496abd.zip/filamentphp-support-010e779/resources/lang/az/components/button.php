<?php

return [

    'messages' => [
        'uploading_file' => 'Fayl yüklənir...',
    ],

];
