<?php

return [

    'label' => 'Gwe-lywio tudalennau',

    'overview' => '{1} Dangos 1 canlyniad|[2,*] Yn dangos :first i :last o :total canlyniadau',

    'fields' => [

        'records_per_page' => [

            'label' => 'fesul tudalen',

            'options' => [
                'all' => 'Pawb',
            ],

        ],

    ],

    'actions' => [

        'go_to_page' => [
            'label' => 'Ewch i dudalen :page',
        ],

        'next' => [
            'label' => 'Nesaf',
        ],

        'previous' => [
            'label' => 'Blaenorol',
        ],

    ],

];
