<?php

return [

    'messages' => [

        'uploading_file' => 'በመጫን ላይ...',
    ],
];
