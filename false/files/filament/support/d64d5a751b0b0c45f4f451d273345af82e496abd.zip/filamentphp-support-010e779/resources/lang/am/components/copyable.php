<?php

return [

    'messages' => [

        'copied' => 'ተቀድቶዋል',
    ],
];
