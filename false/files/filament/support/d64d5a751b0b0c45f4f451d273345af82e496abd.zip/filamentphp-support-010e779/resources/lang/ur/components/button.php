<?php

return [

    'messages' => [
        'uploading_file' => 'فائل اپلوڈ ہو رہی ہے...',
    ],

];
