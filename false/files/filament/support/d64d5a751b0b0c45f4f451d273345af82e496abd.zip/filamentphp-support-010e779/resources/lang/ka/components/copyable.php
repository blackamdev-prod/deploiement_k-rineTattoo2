<?php

return [

    'messages' => [
        'copied' => 'დაკოპირდა',
    ],

];
