<?php

return [

    'messages' => [
        'uploading_file' => 'Качване на файл...',
    ],

];
