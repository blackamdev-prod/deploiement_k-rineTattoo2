<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Luk',
        ],

    ],

];
