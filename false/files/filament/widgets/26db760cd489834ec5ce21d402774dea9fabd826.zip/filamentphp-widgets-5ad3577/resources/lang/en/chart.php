<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filter',
        ],

    ],

];
