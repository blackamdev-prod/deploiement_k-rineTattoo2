<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Фільтр',
        ],

    ],

];
