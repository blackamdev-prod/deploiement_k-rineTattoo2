<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtr',
        ],

    ],

];
