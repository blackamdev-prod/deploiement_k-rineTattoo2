<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtre',
        ],

    ],

];
