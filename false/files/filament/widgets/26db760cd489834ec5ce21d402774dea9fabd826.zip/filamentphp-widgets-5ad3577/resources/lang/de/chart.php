<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtern',
        ],

    ],

];
