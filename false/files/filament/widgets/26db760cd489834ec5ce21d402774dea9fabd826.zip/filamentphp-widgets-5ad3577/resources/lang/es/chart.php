<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtrar',
        ],

    ],

];
