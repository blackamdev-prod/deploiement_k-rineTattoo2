<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Szűrés',
        ],

    ],

];
