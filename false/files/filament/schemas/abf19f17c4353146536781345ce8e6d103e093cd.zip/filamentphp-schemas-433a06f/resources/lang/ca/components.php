<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Enrere',
            ],

            'next_step' => [
                'label' => 'Endavant',
            ],

        ],

    ],

];
