<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'پێشوو',
            ],

            'next_step' => [
                'label' => 'دواتر',
            ],

        ],

    ],

];
