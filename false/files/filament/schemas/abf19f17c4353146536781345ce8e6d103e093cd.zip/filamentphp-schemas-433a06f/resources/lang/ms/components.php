<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Sebelum',
            ],

            'next_step' => [
                'label' => 'Seterus',
            ],

        ],

    ],

];
