<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'ย้อนกลับ',
            ],

            'next_step' => [
                'label' => 'ถัดไป',
            ],

        ],

    ],

];
