<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Буцах',
            ],

            'next_step' => [
                'label' => 'Дараагийн',
            ],

        ],

    ],

];
