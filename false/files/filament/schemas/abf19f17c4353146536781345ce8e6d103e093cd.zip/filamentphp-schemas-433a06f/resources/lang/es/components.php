<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Anterior',
            ],

            'next_step' => [
                'label' => 'Siguiente',
            ],

        ],

    ],

];
