<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Tilbage',
            ],

            'next_step' => [
                'label' => 'Næste',
            ],

        ],

    ],

];
