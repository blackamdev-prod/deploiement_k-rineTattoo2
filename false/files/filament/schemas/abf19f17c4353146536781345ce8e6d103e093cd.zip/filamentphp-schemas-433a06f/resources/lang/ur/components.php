<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'پیچھے جائیں',
            ],

            'next_step' => [
                'label' => 'اگلا مرحلہ',
            ],

        ],

    ],

];
