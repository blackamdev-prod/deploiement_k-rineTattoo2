<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Tilbake',
            ],

            'next_step' => [
                'label' => 'Neste',
            ],

        ],

    ],

];
