<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Nyuma',
            ],

            'next_step' => [
                'label' => 'Mbele',
            ],

        ],

    ],

];
