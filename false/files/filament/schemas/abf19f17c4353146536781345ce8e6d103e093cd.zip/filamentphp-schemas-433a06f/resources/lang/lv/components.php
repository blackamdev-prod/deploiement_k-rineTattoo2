<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Iepriekšējais',
            ],

            'next_step' => [
                'label' => 'Nākamais',
            ],

        ],

    ],

];
