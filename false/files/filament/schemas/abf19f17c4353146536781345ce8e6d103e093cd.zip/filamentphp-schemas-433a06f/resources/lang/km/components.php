<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'ត្រឡប់មកវិញ',
            ],

            'next_step' => [
                'label' => 'បន្ទាប់',
            ],

        ],

    ],

];
