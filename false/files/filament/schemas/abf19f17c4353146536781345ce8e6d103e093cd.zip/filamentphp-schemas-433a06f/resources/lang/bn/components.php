<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'পেছনে',
            ],

            'next_step' => [
                'label' => 'পরবর্তী',
            ],

        ],

    ],

];
