<?php

namespace Filament\Schemas\Components\Contracts;

interface ExposesStateToActionData {}
