<?php

return [

    'form' => [

        'actions' => [

            'save' => [

                'label' => 'ለውጦችን ያስቀምጡ',
            ],
        ],
    ],
    'notifications' => [

        'saved' => [

            'title' => 'ተመዝግቦዋል',
        ],
    ],
];
