<?php

return [

    'title' => 'הצגת :label',

    'breadcrumb' => 'הצגה',

    'content' => [

        'tab' => [
            'label' => 'הצגה',
        ],

    ],

];
