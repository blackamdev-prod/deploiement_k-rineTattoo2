<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'بەڵگەنامە',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
