<?php

return [

    'title' => 'Erreur lors du chargement de la page',

    'body' => 'Une erreur est survenue lors du chargement de cette page. Veuillez réessayer plus tard.',

];
