<?php

return [

    'subject' => 'Sähköpostiasi vaihdetaan',

    'lines' => [
        'Saimme pyynnön vaihtaa tiliisi yhdistetyn sähköpostin. Salasanaasi käytettiin muutoksen vahvistamiseen',
        'Vahvistuksen jälkeen, uusi sähköposti tilillesi tulee olemaan :email.',
        'Voit estää muutoksen ennen kuin se on vahvistettu painamalla alla olevaa nappia.',
        'Jos et tehnyt pyyntöä, ota yhtettä meihin heti.',
    ],

    'action' => 'Estä sähköpostin vaihto',

];
