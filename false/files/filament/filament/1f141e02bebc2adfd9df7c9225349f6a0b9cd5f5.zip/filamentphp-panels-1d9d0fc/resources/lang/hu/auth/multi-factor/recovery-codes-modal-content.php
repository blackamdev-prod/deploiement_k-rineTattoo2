<?php

return [

    'actions' => [

        'Kattints a kódok',

        'copy' => [
            'label' => 'másolásához',
        ],

        'vagy',

        'download' => [
            'label' => 'letöltéséhez',
        ],

        '.',

    ],

    'messages' => [
        'copied' => 'Kimásolva',
    ],

];
