<?php

return [
    'actions' => [
        'Klikněte pro',

        'copy' => [
            'label' => 'zkopírovat',
        ],

        'nebo',

        'download' => [
            'label' => 'stáhnout',
        ],

        'všechny kódy najednou.',
    ],

    'messages' => [
        'copied' => 'Zkopírováno',
    ],
];
