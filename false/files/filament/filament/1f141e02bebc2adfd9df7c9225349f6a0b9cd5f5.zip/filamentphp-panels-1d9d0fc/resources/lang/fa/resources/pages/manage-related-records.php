<?php

return [

    'title' => 'مدیریت :label :relationship',

];
