<?php

return [

    'actions' => [

        'Klikkaa',

        'copy' => [
            'label' => 'kopioidaksesi',
        ],

        'tai',

        'download' => [
            'label' => 'lataa',
        ],

        'kaikki koodit kerralla.',

    ],

    'messages' => [
        'copied' => 'Kopioitu',
    ],

];
