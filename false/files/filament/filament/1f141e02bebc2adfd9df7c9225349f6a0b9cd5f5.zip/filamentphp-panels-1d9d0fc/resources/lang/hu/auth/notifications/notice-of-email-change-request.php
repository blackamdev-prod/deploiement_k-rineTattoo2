<?php

return [

    'subject' => 'Az email címed módosítása folyamatban van',

    'lines' => [
        'Kérelmet kaptunk a fiókodhoz társított email cím megváltoztatására. A jelszavadat meg lett adva változtatás megerősítéséhez.',
        'A megerősítés után a fiókod új email címe a következő lesz: :email.',
        'A változtatást letilthatod, mielőtt megerősítenék, az alábbi gombra kattintva.',
        'Ha nem te tetted ezt a kérelmet, kérjük, vedd fel velünk azonnal a kapcsolatot.',
    ],

    'action' => 'Email változtatás letiltása',

];
