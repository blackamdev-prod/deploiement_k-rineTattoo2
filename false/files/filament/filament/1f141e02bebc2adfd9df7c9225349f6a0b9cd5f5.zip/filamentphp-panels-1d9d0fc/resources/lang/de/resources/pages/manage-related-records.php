<?php

return [

    'title' => ':label :relationship verwalten',

];
