<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'ዘግተህ ውጣ',
        ],

    ],

    'welcome' => 'እንኳን ደህና መጡ',

];
