<?php

return [

    'actions' => [

        'Hacer clic para',

        'copy' => [
            'label' => 'copiar',
        ],

        'o',

        'download' => [
            'label' => 'descargar',
        ],

        'todos los códigos a la vez.',

    ],

    'messages' => [
        'copied' => 'Copiados',
    ],

];
