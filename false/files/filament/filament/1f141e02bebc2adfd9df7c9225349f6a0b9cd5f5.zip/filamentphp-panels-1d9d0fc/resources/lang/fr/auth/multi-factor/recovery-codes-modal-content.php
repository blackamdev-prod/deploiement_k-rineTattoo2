<?php

return [

    'actions' => [

        'Cliquer pour',

        'copy' => [
            'label' => 'copier',
        ],

        'ou',

        'download' => [
            'label' => 'télécharger',
        ],

        'tous les codes en même temps.',

    ],

    'messages' => [
        'copied' => 'Copié',
    ],

];
