<?php

return [

    'actions' => [

        'Click to',

        'copy' => [
            'label' => 'copy',
        ],

        'or',

        'download' => [
            'label' => 'download',
        ],

        'all the codes at once.',

    ],

    'messages' => [
        'copied' => 'Copied',
    ],

];
