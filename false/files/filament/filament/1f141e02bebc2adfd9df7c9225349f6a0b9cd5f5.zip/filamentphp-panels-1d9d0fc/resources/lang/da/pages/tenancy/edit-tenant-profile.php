<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Gem ændringer',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Gemt',
        ],

    ],

];
