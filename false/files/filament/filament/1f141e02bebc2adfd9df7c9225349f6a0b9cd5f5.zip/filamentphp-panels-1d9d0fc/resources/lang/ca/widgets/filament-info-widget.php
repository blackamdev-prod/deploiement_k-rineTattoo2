<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentació',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
