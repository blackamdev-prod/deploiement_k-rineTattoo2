<?php

return [

    'title' => 'Hiba az oldal betöltése közben',

    'body' => 'Hiba történt az oldal betöltése során. Kérjük, próbáld meg később.',

];
