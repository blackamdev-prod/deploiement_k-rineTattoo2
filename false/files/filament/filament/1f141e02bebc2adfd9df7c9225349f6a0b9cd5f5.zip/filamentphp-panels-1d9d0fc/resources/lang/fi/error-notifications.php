<?php

return [

    'title' => 'Virhe sivun latauksessa',

    'body' => 'Sivun lataamisessa oli virhe. Yritä uudelleen myöhemmin.',

];
