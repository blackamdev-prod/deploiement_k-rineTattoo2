<?php

return [

    'title' => 'Ota kaksivaiheinen tunnistautuminen käyttöön (2FA)',

    'heading' => 'Ota kaksivaiheinen tunnistautuminen käyttöön',

    'subheading' => '2FA parantaa tilisi turvallisuutta vaatimalla toisen tunnistustavan kun kirjaudut sisään.',

    'actions' => [

        'continue' => [
            'label' => 'Jatka',
        ],

    ],

];
