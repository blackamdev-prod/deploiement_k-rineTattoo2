<?php

return [

    'title' => 'Configurar la autenticación de dos factores (2FA)',

    'heading' => 'Configura la autenticación de dos factores',

    'subheading' => '2FA agrega una capa adicional de seguridad a su cuenta al requerir una segunda forma de verificación al iniciar sesión.',

    'actions' => [

        'continue' => [
            'label' => 'Continuar',
        ],

    ],

];
