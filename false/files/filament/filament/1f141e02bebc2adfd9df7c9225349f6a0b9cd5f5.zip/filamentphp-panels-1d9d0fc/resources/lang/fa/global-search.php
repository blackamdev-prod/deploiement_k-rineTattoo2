<?php

return [

    'field' => [
        'label' => 'جستجو در کل سایت',
        'placeholder' => 'جستجو',
    ],

    'no_results_message' => 'نتیجه‌ای برای جستجوی شما یافت نشد.',

];
