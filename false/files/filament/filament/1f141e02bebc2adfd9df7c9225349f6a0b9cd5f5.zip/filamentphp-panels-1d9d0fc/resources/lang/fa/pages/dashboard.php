<?php

return [

    'title' => 'داشبورد',

    'actions' => [

        'filter' => [

            'label' => 'فیلتر',

            'modal' => [

                'heading' => 'فیلتر',

                'actions' => [

                    'apply' => [

                        'label' => 'اعمال فیلتر',

                    ],

                ],

            ],

        ],

    ],

];
