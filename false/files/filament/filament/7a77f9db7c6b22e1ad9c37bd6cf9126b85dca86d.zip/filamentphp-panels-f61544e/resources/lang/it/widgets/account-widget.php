<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Disconnetti',
        ],

    ],

    'welcome' => 'Benvenuto',

];
