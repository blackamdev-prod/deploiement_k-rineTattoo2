<?php

return [

    'title' => 'ათვალიერებთ :label',

    'breadcrumb' => 'დათვალიერება',

    'content' => [

        'tab' => [
            'label' => 'დათვალიერება',
        ],

    ],

];
