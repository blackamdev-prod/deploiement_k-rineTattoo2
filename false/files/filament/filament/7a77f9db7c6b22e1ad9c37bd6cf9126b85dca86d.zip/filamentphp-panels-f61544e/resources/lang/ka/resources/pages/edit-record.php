<?php

return [

    'title' => 'არედაქტირებთ :label',

    'breadcrumb' => 'რედაქტირება',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'გაუქმება',
            ],

            'save' => [
                'label' => 'ცვლილებების შენახვა',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'რედაქტირება',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'შენახულია',
        ],

    ],

];
