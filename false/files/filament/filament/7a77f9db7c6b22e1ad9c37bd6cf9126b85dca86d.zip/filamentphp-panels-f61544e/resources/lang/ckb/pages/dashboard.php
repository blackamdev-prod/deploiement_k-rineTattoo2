<?php

return [

    'title' => 'داشبۆرد',

];
