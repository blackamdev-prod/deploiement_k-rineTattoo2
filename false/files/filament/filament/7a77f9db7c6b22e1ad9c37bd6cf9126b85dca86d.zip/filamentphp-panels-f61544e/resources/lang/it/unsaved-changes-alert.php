<?php

return [

    'body' => 'Hai delle modifiche non salvate. Vuoi davvero uscire da questa pagina?',

];
