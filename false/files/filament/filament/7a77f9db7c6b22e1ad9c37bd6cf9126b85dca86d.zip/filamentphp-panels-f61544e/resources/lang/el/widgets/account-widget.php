<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Αποσύνδεση',
        ],

    ],

    'welcome' => 'Καλώς ήρθες',

];
