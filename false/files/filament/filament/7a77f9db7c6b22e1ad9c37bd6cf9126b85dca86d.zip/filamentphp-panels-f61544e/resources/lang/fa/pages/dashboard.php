<?php

return [

    'title' => 'داشبورد',

];
