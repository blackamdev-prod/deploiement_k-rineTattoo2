<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Mostra :count in meno',
                'expand_list' => 'Mostra altri :count',
            ],

            'more_list_items' => 'e altri :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Chiave',
                ],

                'value' => [
                    'label' => 'Valore',
                ],

            ],

            'placeholder' => 'Nessun elemento',

        ],

    ],

];
