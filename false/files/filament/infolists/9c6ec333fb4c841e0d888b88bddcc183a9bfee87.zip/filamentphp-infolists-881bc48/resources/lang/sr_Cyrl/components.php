<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Прикажи :count мање',
                'expand_list' => 'Прикажи :count више',
            ],

            'more_list_items' => 'и :count више',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Кључ',
                ],

                'value' => [
                    'label' => 'Вредност',
                ],

            ],

            'placeholder' => 'Без уноса',

        ],

    ],

];
