<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'הצג פחות :count',
                'expand_list' => 'הצג עוד :count',
            ],

            'more_list_items' => 'ועוד :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'שדה',
                ],

                'value' => [
                    'label' => 'ערך',
                ],

            ],

            'placeholder' => 'אין רשומות',

        ],

    ],

];
