<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Sembunyikan :count lainnya',
                'expand_list' => 'Tampilkan :count lainnya',
            ],

            'more_list_items' => 'dan :count lainnya',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Kunci',
                ],

                'value' => [
                    'label' => 'Nilai',
                ],

            ],

            'placeholder' => 'Tidak ada entri',

        ],

    ],

];
