<?php

return [

    'distinct' => [
        'must_be_selected' => 'យ៉ាងហោចណាស់​មួយ :attribute ត្រូវតែត្រូវបានជ្រើសរើស។',
        'only_one_must_be_selected' => 'តែមួយគត់ :attribute ត្រូវតែត្រូវបានជ្រើសរើស។',
    ],

];
