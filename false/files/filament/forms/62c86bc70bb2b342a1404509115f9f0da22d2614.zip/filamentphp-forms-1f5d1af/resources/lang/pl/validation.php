<?php

return [

    'distinct' => [
        'must_be_selected' => 'Przynajmniej jedno pole :attribute musi być zaznaczone.',
        'only_one_must_be_selected' => 'Tylko jedno pole :attribute musi być zaznaczone.',
    ],

];
