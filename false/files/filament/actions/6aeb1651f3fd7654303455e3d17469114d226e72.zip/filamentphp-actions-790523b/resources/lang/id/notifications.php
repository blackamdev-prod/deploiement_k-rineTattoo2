<?php

return [

    'throttled' => [
        'title' => 'Terlalu banyak permintaan',
        'body' => 'Silakan coba lagi dalam :seconds detik.',
    ],

];
