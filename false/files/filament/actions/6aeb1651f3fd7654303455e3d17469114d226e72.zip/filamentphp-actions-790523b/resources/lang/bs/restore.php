<?php

return [

    'single' => [

        'label' => 'Povrati',

        'modal' => [

            'heading' => 'Povrati :label',

            'actions' => [

                'restore' => [
                    'label' => 'Povrati',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Zapis vraćen',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Izabrani vratiti',

        'modal' => [

            'heading' => 'Povrati :label',

            'actions' => [

                'restore' => [
                    'label' => 'Povratiti',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Zapisi vraćen',
            ],

        ],

    ],

];
