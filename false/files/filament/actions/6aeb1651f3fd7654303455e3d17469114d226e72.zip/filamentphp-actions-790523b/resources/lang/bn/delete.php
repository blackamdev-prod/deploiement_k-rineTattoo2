<?php

return [

    'single' => [

        'label' => 'মুছে ফেলুন',

        'modal' => [

            'heading' => ':label মুছে ফেলুন',

            'actions' => [

                'delete' => [
                    'label' => 'মুছে ফেলুন',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'মুছে ফেলা হয়েছে',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'নির্বাচিত গুলো মুছে ফেলুন',

        'modal' => [

            'heading' => 'নির্বাচিত :label মুছে ফেলুন',

            'actions' => [

                'delete' => [
                    'label' => 'মুছে ফেলুন',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'মুছে ফেলা হয়েছে',
            ],

        ],

    ],

];
