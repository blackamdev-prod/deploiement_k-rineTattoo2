<?php

return [
    'throttled' => [
        'title' => 'Příliš mnoho pokusů',
        'body' => 'Zkuste to prosím znovu za :seconds sekund.',
    ],
];
