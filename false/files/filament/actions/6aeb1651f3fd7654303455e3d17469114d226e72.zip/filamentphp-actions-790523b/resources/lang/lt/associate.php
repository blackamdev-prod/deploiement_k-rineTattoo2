<?php

return [

    'single' => [

        'label' => 'Susieti',

        'modal' => [

            'heading' => 'Susieti :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Įrašas',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Susieta',
                ],

                'associate_another' => [
                    'label' => 'Susieti ir susieti kitą',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Susieta',
            ],

        ],

    ],

];
