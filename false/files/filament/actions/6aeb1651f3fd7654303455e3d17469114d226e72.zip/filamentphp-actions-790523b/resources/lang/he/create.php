<?php

return [

    'single' => [

        'label' => 'יצירת :label',

        'modal' => [

            'heading' => 'יצירת :label',

            'actions' => [

                'create' => [
                    'label' => 'יצירה',
                ],

                'create_another' => [
                    'label' => 'צור וצור עוד אחד',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'נוצר',
            ],

        ],

    ],

];
