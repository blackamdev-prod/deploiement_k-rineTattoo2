<?php

return [

    'trigger' => [

        'label' => 'ድርጊቶች',
    ],
];
