<?php

return [

    'single' => [

        'label' => 'جداکردن',

        'modal' => [

            'heading' => 'جداکردن :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جداکردن',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جداکردن',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'جداکردن انتخاب شده',

        'modal' => [

            'heading' => 'جداکردن :label انتخاب شده',

            'actions' => [

                'dissociate' => [
                    'label' => 'جداکردن انتخاب شده',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جدا شد',
            ],

        ],

    ],

];
