<?php

return [

    'single' => [

        'label' => 'لەبەرگرتنەوە',

        'modal' => [

            'heading' => 'لەبەرگرتنەوەی :label',

            'actions' => [

                'replicate' => [
                    'label' => 'لەبەرگرتنەوە',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'لەبەرگیرایەوە',
            ],

        ],

    ],

];
