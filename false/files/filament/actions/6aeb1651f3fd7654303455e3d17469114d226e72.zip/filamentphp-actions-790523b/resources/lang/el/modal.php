<?php

return [

    'confirmation' => "Είστε σίγουρος/η γι' αυτή την ενέργεια;",

    'actions' => [

        'cancel' => [
            'label' => 'Άκυρο',
        ],

        'confirm' => [
            'label' => 'Επιβεβαίωση',
        ],

        'submit' => [
            'label' => 'Submit',
        ],

    ],

];
