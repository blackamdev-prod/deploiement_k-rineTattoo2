<?php

return [

    'single' => [

        'label' => 'Rediger',

        'modal' => [

            'heading' => 'Rediger :label',

            'actions' => [

                'save' => [
                    'label' => 'Gem ændringer',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Gemt',
            ],

        ],

    ],

];
