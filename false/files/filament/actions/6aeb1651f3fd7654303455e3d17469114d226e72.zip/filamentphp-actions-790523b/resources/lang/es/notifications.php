<?php

return [

    'throttled' => [
        'title' => 'Demasiados intentos',
        'body' => 'Por favor intente nuevamente en :seconds segundos.',
    ],

];
