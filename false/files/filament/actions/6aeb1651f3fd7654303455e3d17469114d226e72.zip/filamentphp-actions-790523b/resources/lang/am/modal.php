<?php

return [

    'confirmation' => 'እርግጠኛ ነዎት ይህን ማድረግ ይፈልጋሉ?',
    'actions' => [

        'cancel' => [

            'label' => 'ይቅር',
        ],
        'confirm' => [

            'label' => 'አጽድቅ',
        ],
        'submit' => [

            'label' => 'መዝግብ',
        ],
    ],
];
