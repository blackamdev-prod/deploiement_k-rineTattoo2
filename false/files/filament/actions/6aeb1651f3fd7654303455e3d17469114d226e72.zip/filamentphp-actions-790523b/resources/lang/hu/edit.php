<?php

return [

    'single' => [

        'label' => 'Szerkesztés',

        'modal' => [

            'heading' => ':label szerkesztése',

            'actions' => [

                'save' => [
                    'label' => 'Mentés',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Mentve',
            ],

        ],

    ],

];
