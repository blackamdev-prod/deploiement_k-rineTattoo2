<?php

return [

    'single' => [

        'label' => 'አጥፋ',
        'modal' => [

            'heading' => ':labelን አጥፋ',
            'actions' => [

                'delete' => [

                    'label' => 'አጥፋ',
                ],
            ],
        ],
        'notifications' => [

            'deleted' => [

                'title' => 'ጠፍቶዋል',
            ],
        ],
    ],
    'multiple' => [

        'label' => 'የተመረጡትን አጥፋ',
        'modal' => [

            'heading' => 'የተመረጡት :labelን አጥፋ',
            'actions' => [

                'delete' => [

                    'label' => 'አጥፋ',
                ],
            ],
        ],
        'notifications' => [

            'deleted' => [

                'title' => 'ጠፍቶዋል',
            ],
        ],
    ],
];
