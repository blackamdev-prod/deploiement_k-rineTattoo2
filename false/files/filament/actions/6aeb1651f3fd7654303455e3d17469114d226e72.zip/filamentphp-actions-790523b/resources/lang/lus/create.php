<?php

return [

    'single' => [

        'label' => ':Label thar',

        'modal' => [

            'heading' => ':Label thar siamna',

            'actions' => [

                'create' => [
                    'label' => 'Siamna',
                ],

                'create_another' => [
                    'label' => 'Pakhat siama adang siam lehna',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'A thar siam ani.',
            ],

        ],

    ],

];
