<?php

return [

    'single' => [

        'label' => '분리',

        'modal' => [

            'heading' => ':label 분리',

            'actions' => [

                'detach' => [
                    'label' => '분리',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => '분리 완료',
            ],

        ],

    ],

    'multiple' => [

        'label' => '선택한 항목 분리',

        'modal' => [

            'heading' => ':label 선택한 항목 분리',

            'actions' => [

                'detach' => [
                    'label' => '선택한 항목 분리',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => '분리 완료',
            ],

        ],

    ],

];
