<?php

return [

    'single' => [

        'label' => 'დაკავშირება',

        'modal' => [

            'heading' => 'აკავშირებ :label',

            'fields' => [

                'record_id' => [
                    'label' => 'ჩანაწერი',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'დაკავშირება',
                ],

                'associate_another' => [
                    'label' => 'დაკავშირება და ახალი დაკავშირება',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'დაკავშირებულია',
            ],

        ],

    ],

];
