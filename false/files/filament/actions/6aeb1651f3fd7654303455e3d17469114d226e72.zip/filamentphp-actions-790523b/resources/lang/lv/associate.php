<?php

return [

    'single' => [

        'label' => 'Saistīt',

        'modal' => [

            'heading' => 'Saistīt :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Ieraksts',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Saistīt',
                ],

                'associate_another' => [
                    'label' => 'Saistīt & saistīt citu',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Saistīts',
            ],

        ],

    ],

];
