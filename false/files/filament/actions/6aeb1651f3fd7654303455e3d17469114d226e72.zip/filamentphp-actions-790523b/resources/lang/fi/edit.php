<?php

return [

    'single' => [

        'label' => 'Muokkaa',

        'modal' => [

            'heading' => 'Muokkaa :label',

            'actions' => [

                'save' => [
                    'label' => 'Tallenna',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Tallennettu',
            ],

        ],

    ],

];
