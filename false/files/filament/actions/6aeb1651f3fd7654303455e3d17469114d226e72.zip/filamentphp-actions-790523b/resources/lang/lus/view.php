<?php

return [

    'single' => [

        'label' => 'Enna',

        'modal' => [

            'heading' => ':Label enna',

            'actions' => [

                'close' => [
                    'label' => 'Khârna',
                ],

            ],

        ],

    ],

];
