<?php

return [

    'modal' => [

        'heading' => 'सूचनाहरू',

        'actions' => [

            'clear' => [
                'label' => 'खाली गर्नुहोस्',
            ],

            'mark_all_as_read' => [
                'label' => 'सबै पढेको रूपमा चिन्ह लगाउनुहोस्',
            ],

        ],

        'empty' => [
            'heading' => 'कुनै सूचना छैन',
            'description' => 'कृपया पछि फेरि जाँच गर्नुहोस्।',
        ],

    ],

];
