<?php

return [

    'modal' => [

        'heading' => '알림',

        'actions' => [

            'clear' => [
                'label' => '전체 삭제',
            ],

            'mark_all_as_read' => [
                'label' => '모두 읽음으로 표시',
            ],

        ],

        'empty' => [
            'heading' => '알림 없음',
            'description' => '나중에 다시 확인해 주세요.',
        ],

    ],

];
