<?php

return [

    'modal' => [

        'heading' => 'Hriattîrna',

        'actions' => [

            'clear' => [
                'label' => 'Then faina',
            ],

            'mark_all_as_read' => [
                'label' => 'Chhiar vek tawh ah dah rawh',
            ],

        ],

        'empty' => [
            'heading' => 'Hriattîrna a awmlo',
            'description' => 'Nakinah ilo check leh dawn nia.',
        ],

    ],

];
