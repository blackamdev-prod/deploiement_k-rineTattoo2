<?php

return [

    'modal' => [

        'heading' => 'Notificações',

        'actions' => [

            'clear' => [
                'label' => 'Limpar',
            ],

            'mark_all_as_read' => [
                'label' => 'Marcar tudo como lido',
            ],

        ],

        'empty' => [
            'heading' => 'Sem notificações',
            'description' => 'Por favor, verifique mais tarde.',
        ],

    ],

];
