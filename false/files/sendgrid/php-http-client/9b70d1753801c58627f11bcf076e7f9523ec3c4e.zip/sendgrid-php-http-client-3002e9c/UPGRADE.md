# Upgrade Guide

_MAJOR version bumps will have upgrade notes posted here._

[2022-05-04] 3.x.x to 4.x.x
---------------------------

### CHANGED - Drop support for PHP versions 5.6, 7.0, 7.1, and 7.2 which are EOL.
