<?php

namespace Illuminate\Contracts\Console;

interface PromptsForMissingInput
{
    //
}
